import numpy as np
from datasketch import MinHash, MinHashLSH

# Trial/Example work
 
# jobs = [
#     "Python, SQL, Machine Learning",
#     "Java, Spring, Microservices",
#     "React, Node.js, JavaScript",
#     "AWS, Docker, Kubernetes",
#     "Data Analysis, Excel, Tableau",
#     "Cloud Computing, Spring, Javascript",
#     "Machine Learning, Python, Data Analysis"
# ]

# users = [
#     "Python, Machine Learning, Data Analysis",
#     "Java, Spring, Hibernate",
#     "React, JavaScript, Frontend Development",
#     "Cloud Computing, AWS, Docker",
# ]

# Run following code for above examples:

# num_hashes = 1024
# num_bands = 512  # More bands for finer granularity
# rows_per_band = num_hashes // num_bands

# job_shingles = [create_shingles(job, k) for job in jobs]
# user_shingles = [create_shingles(user, k) for user in users]
# job_minhashes = [generate_minhash(shingles, num_hashes) for shingles in job_shingles]
# user_minhashes = [generate_minhash(shingles, num_hashes) for shingles in user_shingles]
# job_buckets = lsh_buckets(job_minhashes, num_bands, rows_per_band)

# Find matching jobs for each user using LSH Buckets
# for user_index, user_minhash in enumerate(user_minhashes):
#     matching_jobs = query_lsh_buckets(user_minhash, job_buckets, num_bands, rows_per_band)
#     if matching_jobs:
#         print(f"User {user_index} matches with jobs: {', '.join(map(str, matching_jobs))}")
#     else:
#         print(f"User {user_index} does not match any jobs.")



# Create Shingles (Size 3)
k = 3
def create_shingles(text, k):
    return set(text.split(', '))

# Generate MinHash for each document
def generate_minhash(shingle_set, num_hashes):
    m = MinHash(num_perm=num_hashes) #use datasketh minhash and set num of hashes
    for shingle in shingle_set:
        m.update(shingle.encode('utf8'))
    return m

# Implement LSH with Buckets
def lsh_buckets(minhashes, num_bands, rows_per_band):
    # Create a list of buckets, each bucket is a set of items (jobs or users)
    buckets = {}
    
    for index, minhash in enumerate(minhashes):
        # Create signature
        for band in range(num_bands):
            # Create hash key
            band_signature = minhash.hashvalues[band * rows_per_band : (band + 1) * rows_per_band]
            band_key = tuple(band_signature)
            
            # Add the item to bucket
            if band_key not in buckets:
                buckets[band_key] = set()
            buckets[band_key].add(index)
    
    return buckets

# Query/find matching jobs
def query_lsh_buckets(user_minhash, job_buckets, num_bands, rows_per_band):
    matching_jobs = set()
    
    # Create bands for user
    for band in range(num_bands):
        band_signature = user_minhash.hashvalues[band * rows_per_band : (band + 1) * rows_per_band]
        band_key = tuple(band_signature)
        
        # If the band match something in job buckets
        if band_key in job_buckets:
            matching_jobs.update(job_buckets[band_key])
    
    return matching_jobs

# Comparing location and description, a.ka. making sure the jobs are close to user location
def compare_location_and_description(user_data, job_data):
    filtered_jobs = job_data[
        job_data['Location'].str.contains(user_data['location'], case=False, na=False) &
        job_data['Job Description'].str.contains(user_data['job_description'], case=False, na=False)
    ]
    return filtered_jobs.index.tolist()  # Return the indices of matching jobs
