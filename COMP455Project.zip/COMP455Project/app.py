from flask import Flask, render_template, request, redirect, url_for
import os
import pandas as pd
from JobSimilarityAlgorithm import create_shingles, generate_minhash, lsh_buckets, query_lsh_buckets, compare_location_and_description
from models import get_job_data, save_user_data

app = Flask(__name__, template_folder='templates')

# Folder for uploading resumes
app.config['UPLOAD_FOLDER'] = 'uploads'
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Load job dataset
job_data = get_job_data()

# Create job shingles based on the job description in the job dataset
job_shingles = [create_shingles(job, 3) for job in job_data['Job Description']]
# Create minhashes based on the shingles
job_minhashes = [generate_minhash(shingles, 1024) for shingles in job_shingles]

# Implement LSH for jobs
num_bands = 512
rows_per_band = 1024 // num_bands
# Create buckets for jobs
job_buckets = lsh_buckets(job_minhashes, num_bands, rows_per_band)

@app.route('/')
def index():
    # For displaying all unique locations on front page
    unique_locations = sorted(job_data['Location'].dropna().unique())
    return render_template('index.html', locations=unique_locations)

# When user submit a form 
@app.route('/register', methods=['POST'])
def register():
    name = request.form['name']
    email = request.form['email']
    location = request.form['location']
    job_description = request.form['job_description']
    user_data = {
        "location": location,
        "job_description": job_description
    }

    # Create shingles for the user data (job description and location)
    user_shingles = create_shingles(job_description + ' ' + location, 3)
    
    # Generate MinHash for the user's data
    user_minhash = generate_minhash(user_shingles, 1024)
    
    # Query LSH buckets for matching jobs
    matching_jobs = query_lsh_buckets(user_minhash, job_buckets, num_bands, rows_per_band)

    # Filter jobs by location and job description
    filtered_job_indices = compare_location_and_description(user_data, job_data)
    
    # Retrieve the matching jobs
    jobs_list = []
    for job_idx in filtered_job_indices:
        job_row = job_data.iloc[job_idx]
        jobs_list.append({
            "title": job_row['Job Title'],
            "company": job_row['Company Name'],
            "location": job_row['Location'],
            "salary": job_row['Salary Estimate'],
            "industry": job_row['Industry'],
            "description": job_row['Job Description']
        })

    return render_template('results.html', jobs=jobs_list)

if __name__ == '__main__':
    app.run(debug=True)