import pandas as pd
import sqlite3

# Load job data from CSV
def get_job_data():
    return pd.read_csv("DataAnalyst.csv")  # Path to your CSV file

# Save user data to SQLite database
def save_user_data(name, email, location, job_description):
    conn = sqlite3.connect('user_data.db', check_same_thread=False)
    cursor = conn.cursor()
    
    cursor.execute('''CREATE TABLE IF NOT EXISTS users (
                        id INTEGER PRIMARY KEY,
                        name TEXT,
                        email TEXT,
                        location TEXT,
                        job_description TEXT
                    )''')
    
    cursor.execute('''INSERT INTO users (name, email, location, job_description)
                      VALUES (?, ?, ?, ?)''', 
                   (name, email, location, job_description))
    conn.commit()
    conn.close()
